﻿using System;
using Gtk;

public partial class MainWindow : Gtk.Window
{
    String text = "";
    int numericalBase = 0;
    String result = "";

    public MainWindow() : base(Gtk.WindowType.Toplevel)
    {
        Build();
    }

    protected void OnDeleteEvent(object sender, DeleteEventArgs a)
    {
        Application.Quit();
        a.RetVal = true;
    }

    protected void OnBtnCipherClicked(object sender, EventArgs e)
    {
        text = txtText.Text;
        numericalBase = Convert.ToInt16(txtBase.Text);

        cipherNB();
    }

    protected void OnBtnDecipherClicked(object sender, EventArgs e)
    {
        text = txtText.Text;
        numericalBase = Convert.ToInt16(txtBase.Text);

        deCipherNB();
    }
    protected void cipherNB()
    {
        char[] arrayText = text.ToCharArray();

        foreach (char c in arrayText)
        {
            result += Convert.ToString(c, numericalBase) + " ";
        }

        txtResult.Text = result;
    }

    protected void deCipherNB()
    {
        string[] arrayText = text.Split(' ');

        foreach (string letter in arrayText)
        {
            result += (char)Convert.ToInt64(letter, numericalBase);
        }

        txtResult.Text = result;
    }

    protected void OnBtnClearClicked(object sender, EventArgs e)
    {
        result = "";
        numericalBase = 10;
    }
}
